// CS 210 Project Three - Corner Grocer
// Author: Ben Evans
// Purpose: Track item purchase frequencies and provide query/list/histogram via a menu.
// Notes:
//   - Reads items (whitespace-delimited tokens) from "CS210_Project_Three_Input_File.txt".
//   - Creates "frequency.dat" at program start with "Item Count" per line.
//   - Menu:
//       1) Query frequency of a specific item
//       2) Print all items with counts
//       3) Print histogram (asterisks equal to count)
//       4) Exit
//   - Uses a class (GroceryTracker) and basic input validation.
//   - Case-insensitive counting, but preserves first-seen original casing for display.

#include <iostream>
#include <fstream>
#include <map>
#include <string>
#include <limits>
#include <algorithm>
#include <cctype>
#include <stdexcept>
#include <iomanip>

class GroceryTracker {
public:
    // Load items and build frequency map. Throws on file error.
    explicit GroceryTracker(const std::string& inputPath) {
        loadFromFile(inputPath);
    }

    // Write backup frequency file "frequency.dat"
    void writeFrequencyBackup(const std::string& outputPath = "frequency.dat") const {
        std::ofstream fout(outputPath);
        if (!fout) {
            throw std::runtime_error("Could not create \"" + outputPath + "\"");
        }
        for (const auto& kv : counts_) {
            const std::string& keyLower = kv.first;
            int count = kv.second;
            const std::string& display = displayName_.at(keyLower);
            fout << display << " " << count << "\n";
        }
    }

    // Return frequency for a given item (case-insensitive). Returns 0 if not found.
    int getFrequency(const std::string& item) const {
        std::string key = toLower(item);
        auto it = counts_.find(key);
        return (it == counts_.end()) ? 0 : it->second;
    }

    // Print all items with counts (e.g., "Potatoes 4")
    void printAll() const {
        for (const auto& kv : counts_) {
            const std::string& keyLower = kv.first;
            int count = kv.second;
            const std::string& name = displayName_.at(keyLower);
            std::cout << std::left << std::setw(16) << name
                << " " << count << "\n";
        }
    }

    // Print histogram with asterisks
    void printHistogram(char symbol = '*') const {
        for (const auto& kv : counts_) {
            const std::string& keyLower = kv.first;
            int count = kv.second;
            const std::string& name = displayName_.at(keyLower);
            std::cout << std::left << std::setw(16) << name << " ";
            for (int i = 0; i < count; ++i) std::cout << symbol;
            std::cout << "\n";
        }
    }

private:
    std::map<std::string, int> counts_;                 // key = lowercase item, value = frequency
    std::map<std::string, std::string> displayName_;    // lowercase -> first-seen original casing

    static std::string toLower(const std::string& s) {
        std::string out;
        out.reserve(s.size());
        for (unsigned char ch : s) out.push_back(static_cast<char>(std::tolower(ch)));
        return out;
    }

    void loadFromFile(const std::string& inputPath) {
        std::ifstream fin(inputPath);
        if (!fin) {
            throw std::runtime_error("Could not open \"" + inputPath + "\"");
        }
        std::string token;
        while (fin >> token) {
            if (token.empty()) continue;
            std::string key = toLower(token);
            counts_[key] += 1;
            // Preserve first-seen display casing
            if (displayName_.find(key) == displayName_.end()) {
                displayName_[key] = token;
            }
        }
    }
};

// ----- Input helpers -----

// Read an integer in [lo, hi] with retry on bad input
int readIntInRange(const std::string& prompt, int lo, int hi) {
    while (true) {
        std::cout << prompt;
        int v;
        if (std::cin >> v) {
            if (v >= lo && v <= hi) return v;
            std::cout << "Please enter a number from " << lo << " to " << hi << ".\n";
        }
        else {
            std::cout << "Invalid input. Please enter a whole number.\n";
        }
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }
}

// Read a single word (no spaces). Trims leftover newline beforehand.
std::string readWord(const std::string& prompt) {
    std::cout << prompt;
    std::string w;
    if (!(std::cin >> w)) {
        // Recover from stream failure (e.g., EOF)
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        return "";
    }
    return w;
}

// ----- UI -----

void printMenu() {
    std::cout << "\n====== Corner Grocer Menu ======\n"
        << "1. Search for an item frequency\n"
        << "2. Print all item frequencies\n"
        << "3. Print histogram\n"
        << "4. Exit\n";
}

int main() {
    const std::string inputFile = "CS210_Project_Three_Input_File.txt";

    try {
        // Build frequencies and immediately create backup file.
        GroceryTracker tracker(inputFile);
        tracker.writeFrequencyBackup("frequency.dat");

        // Menu loop
        while (true) {
            printMenu();
            int choice = readIntInRange("Choose an option (1-4): ", 1, 4);

            if (choice == 1) {
                std::string item = readWord("Enter item name: ");
                int freq = tracker.getFrequency(item);
                std::cout << item << " " << freq << "\n";
            }
            else if (choice == 2) {
                tracker.printAll();
            }
            else if (choice == 3) {
                tracker.printHistogram('*');
            }
            else if (choice == 4) {
                std::cout << "Goodbye!\n";
                break;
            }
        }
    }
    catch (const std::exception& ex) {
        std::cerr << "Error: " << ex.what() << "\n";
        return 1;
    }

    return 0;
}
